use std::collections::HashMap;
use std::fs::File;
use std::io::{self, BufRead, Write};
use std::path::Path;
use std::time::Instant;

fn main() -> io::Result<()> {
    let start = Instant::now();

    let path = Path::new("10M_Fact.csv");
    let _display = path.display();
    let file = File::open(&path)?;
    let reader = io::BufReader::new(file);

    let mut data: HashMap<String, Vec<String>> = HashMap::new();
    let mut keys: Vec<String> = Vec::new();

    for (index, line) in reader.lines().enumerate() {
        let line = line?;
        let parts: Vec<&str> = line.split(',').collect();

        if index == 0 {
            for part in &parts {
                keys.push(part.to_string());
                data.insert(part.to_string(), Vec::new());
            }
        } else {
            for (i, part) in parts.iter().enumerate() {
                if let Some(key) = keys.get(i) {
                    data.get_mut(key).unwrap().push(part.to_string());
                }
            }
        }
    }

    let output_file = File::create("data.jbin")?;
    let mut writer = io::BufWriter::new(&output_file);

    for (key, values) in &data {
        writeln!(writer, "{}: {:?}", key, values.join(","))?;
    }

    let duration = start.elapsed();
    println!("Time elapsed is: {:?}", duration);

    Ok(())
}
